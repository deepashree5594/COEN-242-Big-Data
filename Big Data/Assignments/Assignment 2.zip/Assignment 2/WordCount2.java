import java.util.Date;
import java.io.IOException;
import java.util.*;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;


    public class WordCount {

        public static class MyMapper extends
                Mapper<LongWritable, Text, Text, IntWritable> {

            public void map(LongWritable key, Text value, Context context)
                    throws IOException, InterruptedException {
                String line = value.toString();
                String[] words = line.split("\\s+");
                for (String word : words) {
                    word =  word.replaceAll("[^a-zA-Z0-9]+", "");
            if(word.length() > 6)
                    context.write(new Text (word), new IntWritable(1));
                }
            }
        }
        public static class MyReducer extends
                Reducer<Text, IntWritable, Text, IntWritable> {
            public void reduce(Text key, Iterable<IntWritable> values,
                               Context context) throws IOException, InterruptedException {
                int sum = 0;
                for (IntWritable val : values) {
                    sum += val.get();
                }
                context.write(key, new IntWritable(sum));
            }
        }


/*
 *  To run the second operation to obtain the top 100 frequently used words with
 *  length greater than 6, uncomment the below code of using partitioner
 *  We use two reducers here, reducer 0 stores all words with length greater than 6
 *  and reducer 1 stores remaining words
 */

/*

    public static class MyPartitioner extends Partitioner<Text, IntWritable> {
        
        public int getPartition(Text key, IntWritable value, int numPartitions) {

            String myKey = key.toString();

            if(myKey.length() > 6)
                return 0;
            else
                return 1;
        }
    }
*/
         public static void main(String[] args) throws Exception {
 
            Date date;
            long start, end; // for recording starting and end time of job
            date = new Date();
            start = date.getTime(); // starting timer
            Configuration conf = new Configuration();

      /*
       * Setting map output compression to true
      */
        //    conf.setBoolean("mapreduce.map.output.compress", true);           
            Job job = Job.getInstance(conf);

        
    /*
    * Set the number of reducers to 2 while using partitioners to execute the 
    *  second operation as mentioned above also uncomment the setPartionerClass     
    */  
    
       // job.setNumReduceTasks(192);
      //job.setPartitionerClass(MyPartitioner.class);

            job.setJarByClass(WordCount.class);
            job.setOutputKeyClass(Text.class);
            job.setOutputValueClass(IntWritable.class);
            job.setMapperClass(MyMapper.class);

        /* Setting the combiner class*/

            //job.setCombinerClass(MyReducer.class);
            job.setReducerClass(MyReducer.class);
            job.setInputFormatClass(TextInputFormat.class);
            job.setOutputFormatClass(TextOutputFormat.class);
            FileInputFormat.setInputPaths(job, new Path(args[0]));

        /* Uncomment this to change the input split size to
        *  change the number of mappers
        *  setMinInputSplitSize to reduce the number of mappers by setting the split
        *  size to larger value than block size of cluster
        *  setMaxInputSplitSize to increase the number of mappers by setting the split
        *  size lesser than block size of cluster 
        */

            //FileInputFormat.setMinInputSplitSize(job, 399998000);
            //FileInputFormat.setMaxInputSplitSize(job,    90000000);

            FileOutputFormat.setOutputPath(job, new Path(args[1]));
            boolean status = job.waitForCompletion(true);
            date = new Date(); 
            end = date.getTime(); //end timer
            System.out.println("Execution time: Total time ="+(end-start)*0.001F);
            if (status) {
                System.exit(0);
            } else {
                System.exit(1);
            }
        }
    }